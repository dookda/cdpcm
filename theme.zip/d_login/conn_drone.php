<?php
//ionic test 202.29.52.232 pgis@CGI@2015
$conn_drone = "host=localhost dbname=cdpcm user=postgres password=1234";

?>